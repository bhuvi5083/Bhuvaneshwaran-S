# Resume & Certifications

My professional resume and cloud certifications for System Admin / CloudOps roles.