# AWS VPC Infrastructure

Manual + Terraform-based setup of secure AWS infrastructure:
- VPC with public/private subnets
- EC2, NAT Gateway, Route Tables
- Security Groups & Internet Gateway