# AWS CloudOps Automation

This repo contains CloudOps scripts and automation tasks using AWS CLI and PowerShell/Bash.

- Start/Stop EC2 Instances
- EBS Snapshot Automation
- IAM User & Policy Management
- Instance Health Monitoring