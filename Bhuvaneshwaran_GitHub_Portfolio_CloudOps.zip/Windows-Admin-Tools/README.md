# Windows Admin Tools

A collection of PowerShell scripts used for daily sysadmin tasks:
- AD user automation
- Remote system monitoring
- Cleanup and service control